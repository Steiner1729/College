/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package college;

/**
 *
 * @author SRCOEM
 */
public class Studentinfo {
    String name;
    String gender;
    String depname;
    double cgpa;
    
    Studentinfo(String n, String gn, String dn, double cgp)
    {
        name = n;
        gender = gn;
        depname = dn;
        cgpa = cgp;
    }
    
    void display()
    {
        System.out.print("STUDENT INFO : \nNAME :" + name + "\nGENDER :" + gender + "\nDEPARTMENT NAME :" + depname + "\nCGPA :" + cgpa);
    } 
}

class placement extends Studentinfo
{
    String compname;
    int anpack;
    int lnum;
    
    placement(String n, String gn, String dn, double cgp, String cname, int anpack, int lnum)
    {
        super(n, gn, dn, cgp);
        compname = cname;
        this.anpack = anpack;
        this.lnum = lnum;
    }
    
    void display()
    {
        System.out.print("PLACEMENT :\nNAME :" + name + "\nGENDER :" + gender + "\nDEPARTMENT NAME :" + depname + "\nCGPA :" + cgpa + "\nCOMPANY NAME :" + compname + "\nANNUAL PACKAGE :" + anpack + "\nJOINING LETTER NUMBER :" + lnum);
    }
}


class highstudies extends Studentinfo
{
    String degname;
    String colname;
    String alm;
    String compexname;
    int compexscore;
    
    highstudies(String n, String gn, String dn, double cgp, String dname, String colname, String alm, String compexname, int compexscore)
    {
        super(n, gn, dn, cgp);
        degname = dname;
        this.colname = colname;
        this.alm = alm;
        this.compexname = compexname;
        this.compexscore = compexscore;
    }
    
    void display()
    {
        System.out.print("HIGHER EDUCATION :\nNAME :" + name + "\nGENDER :" + gender + "\nDEPARTMENT NAME :" + depname + "\nCGPA :" + cgpa + "\nCOLLEGE NAME :" + colname + "\nADMISSION LETTER NUMBER :" + alm + "\nDEGREE NAME :" + degname + "\nCOMPETITIVE EXAM NAME :" + compexname + "\nCOMPETITIVE EXAM SCORE :" + compexscore);
        
    }
}


class entrepren extends Studentinfo
{
    String compname;
    String sector;
    int numempl;
    int anturnover;
    
    entrepren(String n, String gn, String dn, double cgp, String compname, String sec, int numempl, int anturnover)
    {
        super(n, gn, dn, cgp);
        this.compname = compname;
        sector = sec;
        this.numempl = numempl;
        this.anturnover = anturnover;
    }
    
        void display()
    {
        System.out.print("ENTREPRENEUR :\nNAME :" + name + "\nGENDER :" + gender + "\nDEPARTMENT NAME :" + depname + "\nCGPA :" + cgpa + "\nCOMPANY NAME :" + compname + "\nANNUAL TURNOVER :" + anturnover + "\nSECTOR :" + sector + "\nNUMBER OF EMPLOYEES :" + numempl);
    }
}