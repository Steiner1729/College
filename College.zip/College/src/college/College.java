/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package college;

/**
 *
 * @author SRCOEM
 */
public class College {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Studentinfo s1 = new Studentinfo(
        "retsopmi",
        "Male",
        "CSE", 
        7.55);
        
        Studentinfo s2 = new placement(
        "Sussika",
        "Female",
        "CSE", 
        8.55,
        "AMAZON",
        1000000,
        5186);
                
        Studentinfo s3 = new highstudies(
        "Amongesh",
        "Male",
        "CSE", 
        10.00,
        "MSC",
        "HARVARD",
        "A5168",
        "GATE",
        100);
        
        Studentinfo s4 = new entrepren(
        "Gurov",
        "Male",
        "CSE", 
        10.00,
        "RIVERS",
        "TERTIARY",
        100,
        20000000);
        
        s1.display();
        System.out.print("\n\n");
        s2.display();
        System.out.print("\n\n");
        s3.display();
        System.out.print("\n\n");
        s4.display();
        System.out.print("\n\n");
        
        Studentinfo s[] = new Studentinfo[4];
        s[0] = s1;
        s[1] = s2;
        s[2] = s3;
        s[3] = s4;
        
        for(int i = 0; i < 4 ; i++)
        {
            s[i].display();
            System.out.print("\n\n");
        }
    }
    
}
